package com.example.moblist;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class MobListMod implements ModInitializer {

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(this::onServerStarted);
    }

    private void onServerStarted(MinecraftServer server) {
        Registry<EntityType<?>> entityRegistry = server.getRegistryManager().get(RegistryKeys.ENTITY_TYPE);

        List<String> animals = StreamSupport.stream(entityRegistry.spliterator(), false)
            .filter(entityType -> entityType.getSpawnGroup() == SpawnGroup.CREATURE)
            .map(entityType -> entityRegistry.getKey(entityType)
                .map(registryKey -> registryKey.getValue().toString())
                .orElse("unknown"))
            .sorted()
            .collect(Collectors.toList());

        File file = new File("entity_list.json");

        try (FileWriter writer = new FileWriter(file)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(animals, writer);
            server.sendMessage(Text.literal("Animal entity list saved to " + file.getAbsolutePath()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
